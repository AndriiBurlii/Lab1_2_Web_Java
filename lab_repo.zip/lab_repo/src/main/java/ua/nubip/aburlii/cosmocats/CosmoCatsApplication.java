
package ua.nubip.aburlii.cosmocats;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CosmoCatsApplication {
    public static void main(String[] args) {
        SpringApplication.run(CosmoCatsApplication.class, args);
    }
}
