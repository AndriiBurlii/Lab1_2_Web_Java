
package ua.nubip.aburlii.cosmocats.service;

import org.springframework.stereotype.Service;
import ua.nubip.aburlii.cosmocats.domain.Product;
import ua.nubip.aburlii.cosmocats.repo.InMemoryProductRepository;

import java.util.List;
import java.util.Optional;

@Service
public class ProductServiceImpl implements ProductService {

    private final InMemoryProductRepository repo = new InMemoryProductRepository();

    @Override
    public Product create(Product p) {
        if (p.getPriceCents() < 0 || p.getStock() < 0) throw new IllegalArgumentException("Invalid product");
        return repo.save(p);
    }

    @Override
    public Optional<Product> get(Long id) {
        return repo.findById(id);
    }

    @Override
    public List<Product> list() {
        return repo.findAll();
    }

    @Override
    public Product update(Long id, Product p) {
        Product existing = repo.findById(id).orElseThrow(() -> new IllegalArgumentException("Not found"));
        if (p.getName() != null) existing.setName(p.getName());
        if (p.getStock() != null && p.getStock() >= 0) existing.setStock(p.getStock());
        if (p.getPriceCents() != null && p.getPriceCents() >= 0) existing.setPriceCents(p.getPriceCents());
        repo.save(existing);
        return existing;
    }

    @Override
    public boolean delete(Long id) {
        return repo.deleteById(id);
    }
}
