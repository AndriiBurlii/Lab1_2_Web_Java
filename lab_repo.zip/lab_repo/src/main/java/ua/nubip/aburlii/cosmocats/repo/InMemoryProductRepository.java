
package ua.nubip.aburlii.cosmocats.repo;

import ua.nubip.aburlii.cosmocats.domain.Product;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

public class InMemoryProductRepository {
    private final Map<Long, Product> data = new ConcurrentHashMap<>();
    private final AtomicLong seq = new AtomicLong(1000);

    public Product save(Product p) {
        if (p.getId() == null) {
            p.setId(seq.incrementAndGet());
        }
        data.put(p.getId(), p);
        return p;
    }

    public Optional<Product> findById(Long id) { return Optional.ofNullable(data.get(id)); }

    public List<Product> findAll() { return new ArrayList<>(data.values()); }

    public boolean deleteById(Long id) { return data.remove(id) != null; }

    public void clear() { data.clear(); }
}
