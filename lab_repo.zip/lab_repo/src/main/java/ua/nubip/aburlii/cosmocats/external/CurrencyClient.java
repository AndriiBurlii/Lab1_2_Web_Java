
package ua.nubip.aburlii.cosmocats.external;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class CurrencyClient {
    private final RestTemplate rest = new RestTemplate();

    // Returns rate to convert cents (UAH) -> credits
    public double getIntergalacticRate() {
        ResponseEntity<String> resp = rest.getForEntity("http://localhost:8089/rates/credits", String.class);
        if (!resp.getStatusCode().is2xxSuccessful() || resp.getBody() == null) return 1.0;
        try {
            return Double.parseDouble(resp.getBody());
        } catch (NumberFormatException e) {
            return 1.0;
        }
    }
}
