
package ua.nubip.aburlii.cosmocats.service;

import org.springframework.stereotype.Service;
import ua.nubip.aburlii.cosmocats.external.CurrencyClient;

@Service
public class PricingService {
    private final CurrencyClient currencyClient;

    public PricingService(CurrencyClient currencyClient) {
        this.currencyClient = currencyClient;
    }

    public double priceInCredits(int priceCents) {
        double rate = currencyClient.getIntergalacticRate();
        return Math.round((priceCents / 100.0) * rate * 100.0) / 100.0;
    }
}
