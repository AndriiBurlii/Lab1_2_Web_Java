
package ua.nubip.aburlii.cosmocats.service;

import ua.nubip.aburlii.cosmocats.domain.Product;

import java.util.List;
import java.util.Optional;

public interface ProductService {
    Product create(Product p);
    Optional<Product> get(Long id);
    List<Product> list();
    Product update(Long id, Product p);
    boolean delete(Long id);
}
