
package ua.nubip.aburlii.cosmocats.web;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import ua.nubip.aburlii.cosmocats.domain.Product;
import ua.nubip.aburlii.cosmocats.service.ProductService;

import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ProductController.class)
class ProductControllerValidationTest {

    @Autowired MockMvc mvc;
    @Autowired ObjectMapper om;

    @MockBean ProductService service;

    @Test
    void createPositive() throws Exception {
        Product in = new Product(null, "Космокіт-стікер", 3, 5000);
        Product out = new Product(1L, in.getName(), in.getStock(), in.getPriceCents());
        when(service.create(any(Product.class))).thenReturn(out);

        mvc.perform(post("/api/products")
                .contentType(MediaType.APPLICATION_JSON)
                .content(om.writeValueAsString(in)))
           .andExpect(status().isCreated())
           .andExpect(header().string("Location", "/api/products/1"))
           .andExpect(jsonPath("$.name").value("Космокіт-стікер"));
    }

    @Test
    void createNegativeValidation() throws Exception {
        Product bad = new Product(null, "", -1, -1);

        mvc.perform(post("/api/products")
                .contentType(MediaType.APPLICATION_JSON)
                .content(om.writeValueAsString(bad)))
           .andExpect(status().isBadRequest());
    }

    @Test
    void getNotFound() throws Exception {
        when(service.get(123L)).thenReturn(Optional.empty());
        mvc.perform(get("/api/products/123"))
           .andExpect(status().isNotFound());
    }
}
