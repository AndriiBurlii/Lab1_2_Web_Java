
package ua.nubip.aburlii.cosmocats;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CosmoCatsApplicationTest {
    @Test
    void contextLoads() {} 
}
