
package ua.nubip.aburlii.cosmocats.service;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import ua.nubip.aburlii.cosmocats.domain.Product;

import static org.assertj.core.api.Assertions.*;

public class ProductServiceImplTest {

    ProductServiceImpl service = new ProductServiceImpl();

    @Nested
    class Create {
        @Test
        @DisplayName("створює коректний продукт")
        void createOk() {
            Product p = new Product(null, "Лазерна указка", 5, 12345);
            Product saved = service.create(p);
            assertThat(saved.getId()).isNotNull();
            assertThat(service.get(saved.getId())).isPresent();
        }

        @Test
        @DisplayName("кидає помилку при від'ємній ціні")
        void createInvalid() {
            Product p = new Product(null, "Поганий товар", 1, -1);
            assertThatThrownBy(() -> service.create(p)).isInstanceOf(IllegalArgumentException.class);
        }
    }

    @Test
    void updateAndDeleteFlow() {
        Product p = service.create(new Product(null, "Антиматерія", 10, 999));
        Long id = p.getId();
        Product upd = service.update(id, new Product(null, "Антиматерія v2", 7, 1500));
        assertThat(upd.getName()).contains("v2");
        assertThat(service.delete(id)).isTrue();
        assertThat(service.get(id)).isEmpty();
    }
}
