
package ua.nubip.aburlii.cosmocats.service;

import com.github.tomakehurst.wiremock.WireMockServer;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import ua.nubip.aburlii.cosmocats.external.CurrencyClient;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static org.assertj.core.api.Assertions.assertThat;

public class PricingServiceWireMockTest {

    WireMockServer wm;
    PricingService service;

    @BeforeEach
    void setup() {
        wm = new WireMockServer(8089);
        wm.start();
        configureFor("localhost", 8089);
        stubFor(get(urlEqualTo("/rates/credits")).willReturn(aResponse().withStatus(200).withBody("3.5")));
        service = new PricingService(new CurrencyClient());
    }

    @AfterEach
    void tearDown() {
        wm.stop();
    }

    @Test
    void convertsUsingStubbedRate() {
        double credits = service.priceInCredits(10000); // 100.00
        assertThat(credits).isEqualTo(350.0);
    }
}
